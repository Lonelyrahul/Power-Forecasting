kubectl create ns arango-single
# Add helm repository
helm repo add kube-arangodb https://arangodb.github.io/kube-arangodb
# To use `ArangoLocalStorage`, set field `operator.features.storage` to true
helm upgrade --install arango-operator kube-arangodb/kube-arangodb --set "operator.features.storage=true" --set "operator.features.deployment=true" --set "operator.tls.caSecretName=" --set "operator.tls.keyfileSecretName=" --set "operator.tls.autoMount=false" --set "deployment.args[0]=--server.endpoint=tcp://0.0.0.0:8529" --set "deployment.auth.jwtSecretName=" -f custom-values.yaml -n arango-single


kubectl apply -f arango-single.yaml
#kubectl apply -f arango-expose.yaml
